import { motion, AnimatePresence } from "motion/react";
import { 
  Globe, 
  Cpu, 
  MessageSquare, 
  Zap, 
  Palette, 
  School, 
  Hospital, 
  Store, 
  Briefcase,
  Check,
  ArrowRight,
  Menu,
  X,
  Instagram,
  Twitter,
  Linkedin,
  Facebook,
  Mail,
  Phone,
  MapPin,
  Smartphone,
  Cloud,
  Users,
  Lightbulb,
  Send
} from "lucide-react";
import { useState, useEffect } from "react";

// --- Components ---

const ContactModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-slate-900">Get Started with ThynkBEN</h3>
                <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
                  <X size={24} />
                </button>
              </div>
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); alert("Message sent! We'll contact you shortly."); onClose(); }}>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                  <input type="text" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address</label>
                  <input type="email" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Service Interested In</label>
                  <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all">
                    <option>AI Solutions</option>
                    <option>Mobile App Development</option>
                    <option>Cloud & Automation</option>
                    <option>Consulting</option>
                    <option>Website Development</option>
                    <option>Business Automation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Message</label>
                  <textarea rows={3} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" placeholder="Tell us about your project..."></textarea>
                </div>
                <button type="submit" className="w-full btn-primary py-4 flex items-center justify-center gap-2">
                  Send Message <Send size={18} />
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const Header = ({ onOpenContact }: { onOpenContact: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Services", href: "#services" },
    { name: "Solutions", href: "#solutions" },
    { name: "Pricing", href: "#pricing" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-white/80 backdrop-blur-md border-b border-slate-100 py-3" : "bg-transparent py-5"}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="#home" className="text-2xl font-bold text-primary tracking-tight">
          ThynkBEN
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} className="text-sm font-medium text-slate-600 hover:text-primary transition-colors">
              {link.name}
            </a>
          ))}
          <button onClick={onOpenContact} className="btn-primary text-sm">Get Started</button>
        </nav>

        {/* Mobile Toggle */}
        <button className="md:hidden text-slate-900" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-slate-100 p-6 flex flex-col space-y-4 shadow-xl overflow-hidden"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-lg font-medium text-slate-600"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <button onClick={() => { setIsOpen(false); onOpenContact(); }} className="btn-primary w-full">Get Started</button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

const Hero = ({ onOpenContact }: { onOpenContact: () => void }) => {
  return (
    <section id="home" className="pt-32 pb-20 px-6 md:px-12 lg:px-24 overflow-hidden">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.1] tracking-tight text-slate-900 mb-6">
            We Build Digital <span className="text-primary">Systems</span> That Grow Your Business
          </h1>
          <p className="text-xl text-slate-600 mb-10 max-w-lg leading-relaxed">
            From high-performance websites to intelligent automation, we help businesses go digital and scale faster than ever.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={onOpenContact} className="btn-primary text-lg px-8">Book Free Consultation</button>
            <a href="#services" className="btn-secondary text-lg px-8 flex items-center justify-center gap-2">
              View Services <ArrowRight size={20} />
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl border border-slate-200">
             <img 
              src="https://picsum.photos/seed/tech-dashboard/1200/800" 
              alt="Modern Dashboard" 
              className="w-full h-auto"
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Decorative elements */}
          <div className="absolute -top-10 -right-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl -z-10" />
          <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-blue-400/10 rounded-full blur-3xl -z-10" />
          
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -right-6 top-1/4 bg-white p-4 rounded-xl shadow-lg border border-slate-100 hidden md:block"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                <Zap size={20} />
              </div>
              <div>
                <p className="text-xs text-slate-500">Efficiency</p>
                <p className="text-sm font-bold">+145% Growth</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const Trust = () => {
  const items = [
    { icon: <Globe className="text-primary" />, text: "Helping Local Businesses Go Digital" },
    { icon: <Zap className="text-primary" />, text: "Fast Delivery" },
    { icon: <Briefcase className="text-primary" />, text: "Affordable Pricing" },
  ];

  return (
    <section className="py-12 border-y border-slate-100 bg-slate-50/30">
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-wrap justify-center md:justify-between gap-8 md:gap-4">
        {items.map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="flex items-center gap-3"
          >
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-100">
              {item.icon}
            </div>
            <span className="font-semibold text-slate-700">{item.text}</span>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const Services = ({ onOpenContact }: { onOpenContact: () => void }) => {
  const services = [
    { 
      title: "AI Solutions", 
      desc: "Leverage the power of Artificial Intelligence to gain a competitive edge and automate complex decisions.",
      icon: <Zap size={32} />
    },
    { 
      title: "Mobile App Development", 
      desc: "Native and cross-platform mobile applications that provide seamless user experiences on the go.",
      icon: <Smartphone size={32} />
    },
    { 
      title: "Cloud & Automation", 
      desc: "Scalable cloud infrastructure and intelligent automation workflows to optimize your business operations.",
      icon: <Cloud size={32} />
    },
    { 
      title: "Consulting", 
      desc: "Expert strategic guidance to help you navigate the digital landscape and achieve your business goals.",
      icon: <Users size={32} />
    },
    { 
      title: "Website Development", 
      desc: "High-performance, conversion-focused websites built with the latest technologies.",
      icon: <Globe size={32} />
    },
    { 
      title: "Business Automation", 
      desc: "Streamline your workflows and eliminate repetitive tasks with custom automation.",
      icon: <Cpu size={32} />
    },
  ];

  return (
    <section id="services" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold tracking-widest uppercase text-xs mb-4"
          >
            Our Expertise
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-slate-900"
          >
            Services That Drive Results
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 rounded-2xl border border-slate-100 bg-white card-hover group"
            >
              <div className="w-14 h-14 bg-primary/5 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-white transition-colors">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-900">{service.title}</h3>
              <p className="text-slate-600 mb-6 leading-relaxed">{service.desc}</p>
              <button onClick={onOpenContact} className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
                Learn More <ArrowRight size={18} />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Solutions = () => {
  const solutions = [
    {
      title: "For Schools",
      problem: "Manual attendance and fragmented communication.",
      solution: "Integrated management systems with automated parent notifications.",
      icon: <School className="text-primary" />,
      img: "https://picsum.photos/seed/education-system/1200/800"
    },
    {
      title: "For Hospitals",
      problem: "Complex appointment scheduling and patient records.",
      solution: "Seamless digital booking and secure cloud-based record management.",
      icon: <Hospital className="text-primary" />,
      img: "https://picsum.photos/seed/medical-tech/1200/800"
    },
    {
      title: "For Small Businesses",
      problem: "Limited online presence and manual sales tracking.",
      solution: "E-commerce platforms and automated CRM for growth.",
      icon: <Store className="text-primary" />,
      img: "https://picsum.photos/seed/business-growth/1200/800"
    },
    {
      title: "For Agencies",
      problem: "Inefficient client onboarding and reporting.",
      solution: "White-label client portals and automated performance dashboards.",
      icon: <Briefcase className="text-primary" />,
      img: "https://picsum.photos/seed/agency-workspace/1200/800"
    }
  ];

  return (
    <section id="solutions" className="section-padding bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">Tailored Solutions</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">We solve real-world business problems with cutting-edge digital systems.</p>
        </div>

        <div className="space-y-24">
          {solutions.map((sol, i) => (
            <div key={i} className={`flex flex-col lg:items-center gap-12 ${i % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"}`}>
              <motion.div 
                initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="lg:w-1/2"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                    {sol.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900">{sol.title}</h3>
                </div>
                <div className="space-y-6">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">The Problem</p>
                    <p className="text-lg text-slate-600 italic">"{sol.problem}"</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">The ThynkBEN Solution</p>
                    <p className="text-xl font-medium text-slate-900">{sol.solution}</p>
                  </div>
                  <a href="#contact" className="btn-secondary mt-4 inline-block">See Case Study</a>
                </div>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="lg:w-1/2 rounded-2xl overflow-hidden shadow-xl border border-slate-200"
              >
                <img src={sol.img} alt={sol.title} className="w-full h-full object-cover aspect-video" referrerPolicy="no-referrer" />
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = ({ onOpenContact }: { onOpenContact: () => void }) => {
  const plans = [
    {
      name: "Starter",
      price: "19,999",
      features: [
        "Professional Website Development",
        "Mobile Responsive Design",
        "Basic SEO & Performance",
        "Consulting (Initial Strategy)",
        "1 Month Support"
      ],
      highlight: false
    },
    {
      name: "Growth",
      price: "49,999",
      features: [
        "Everything in Starter",
        "Business Automation Workflows",
        "Cloud & Automation (Basic Setup)",
        "CRM & WhatsApp Integration",
        "3 Months Priority Support"
      ],
      highlight: true
    },
    {
      name: "Premium",
      price: "99,999",
      features: [
        "Everything in Growth",
        "Custom AI Solutions",
        "Mobile App Development (iOS/Android)",
        "Advanced Cloud Infrastructure",
        "Ongoing Strategic Consulting",
        "24/7 Priority Support"
      ],
      highlight: false
    }
  ];

  return (
    <section id="pricing" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">Simple, Transparent Pricing</h2>
          <p className="text-slate-600">Choose the plan that's right for your business growth.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-center">
          {plans.map((plan, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`p-10 rounded-3xl border ${plan.highlight ? "border-primary shadow-2xl shadow-primary/10 bg-white scale-105 z-10" : "border-slate-100 bg-slate-50/50"}`}
            >
              {plan.highlight && (
                <span className="bg-primary text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-6 inline-block">
                  Best Value
                </span>
              )}
              <h3 className="text-2xl font-bold mb-2 text-slate-900">{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-8">
                <span className="text-4xl font-bold text-slate-900">₹{plan.price}</span>
                <span className="text-slate-500">/project</span>
              </div>
              <ul className="space-y-4 mb-10">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-center gap-3 text-slate-600">
                    <Check size={18} className="text-primary flex-shrink-0" />
                    <span className="text-sm">{feat}</span>
                  </li>
                ))}
              </ul>
              <button onClick={onOpenContact} className={`w-full py-4 rounded-xl font-bold transition-all ${plan.highlight ? "bg-primary text-white hover:opacity-90" : "bg-white text-primary border border-primary hover:bg-primary/5"}`}>
                Choose {plan.name}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Portfolio = () => {
  const projects = [
    { title: "EduStream Pro", category: "School Management", img: "https://picsum.photos/seed/school-app/800/600" },
    { title: "HealthSync AI", category: "Hospital System", img: "https://picsum.photos/seed/medical-app/800/600" },
    { title: "RetailFlow", category: "Business Automation", img: "https://picsum.photos/seed/retail-app/800/600" },
  ];

  return (
    <section className="section-padding bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <p className="text-primary font-bold tracking-widest uppercase text-xs mb-4">Our Work</p>
            <h2 className="text-4xl md:text-5xl font-bold">Featured Projects</h2>
          </div>
          <a href="#contact" className="btn-primary">View All Projects</a>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((p, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="group cursor-pointer"
            >
              <div className="rounded-2xl overflow-hidden mb-6 aspect-[4/3]">
                <img src={p.img} alt={p.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" referrerPolicy="no-referrer" />
              </div>
              <p className="text-primary font-medium text-sm mb-2">{p.category}</p>
              <h3 className="text-2xl font-bold group-hover:text-primary transition-colors">{p.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const reviews = [
    { name: "Rajesh Kumar", role: "School Principal", text: "ThynkBEN transformed our manual processes into a seamless digital experience. Our parents are much happier now." },
    { name: "Dr. Anita Sharma", role: "Clinic Owner", text: "The appointment automation saved us hours of work every week. Highly professional team and fast delivery." },
    { name: "Vikram Singh", role: "Retailer", text: "My sales increased by 40% after they set up our WhatsApp marketing and CRM. Best investment for my business." },
  ];

  return (
    <section className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900">What Our Clients Say</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((r, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="p-8 rounded-2xl bg-slate-50 border border-slate-100"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, j) => <Check key={j} size={16} className="text-yellow-500 fill-yellow-500" />)}
              </div>
              <p className="text-slate-600 italic mb-8 leading-relaxed">"{r.text}"</p>
              <div>
                <p className="font-bold text-slate-900">{r.name}</p>
                <p className="text-sm text-slate-500">{r.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FinalCTA = ({ onOpenContact }: { onOpenContact: () => void }) => {
  return (
    <section className="section-padding bg-primary relative overflow-hidden">
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Ready to take your business online?</h2>
        <p className="text-blue-100 text-xl mb-12">Join 50+ businesses that scaled their operations with ThynkBEN digital systems.</p>
        <button onClick={onOpenContact} className="bg-white text-primary px-10 py-5 rounded-full font-bold text-xl shadow-xl hover:bg-blue-50 transition-all active:scale-95">
          Book Free Call Now
        </button>
      </div>
      {/* Decorative circles */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400/10 rounded-full translate-x-1/2 translate-y-1/2 blur-3xl" />
    </section>
  );
};

const Footer = () => {
  return (
    <footer id="contact" className="bg-slate-50 pt-20 pb-10 px-6 md:px-12 lg:px-24 border-t border-slate-200">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
        <div className="col-span-1 lg:col-span-1">
          <a href="#" className="text-3xl font-bold text-primary mb-6 block">ThynkBEN</a>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Building the digital future for local businesses. We specialize in high-end websites and intelligent automation.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm hover:text-primary transition-colors"><Twitter size={20} /></a>
            <a href="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm hover:text-primary transition-colors"><Instagram size={20} /></a>
            <a href="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm hover:text-primary transition-colors"><Linkedin size={20} /></a>
            <a href="#" className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm hover:text-primary transition-colors"><Facebook size={20} /></a>
          </div>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 mb-6">Quick Links</h4>
          <ul className="space-y-4">
            <li><a href="#home" className="text-slate-500 hover:text-primary transition-colors">Home</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Services</a></li>
            <li><a href="#solutions" className="text-slate-500 hover:text-primary transition-colors">Solutions</a></li>
            <li><a href="#pricing" className="text-slate-500 hover:text-primary transition-colors">Pricing</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 mb-6">Services</h4>
          <ul className="space-y-4">
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">AI Solutions</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Mobile App Development</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Cloud & Automation</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Consulting</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Website Development</a></li>
            <li><a href="#services" className="text-slate-500 hover:text-primary transition-colors">Business Automation</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 mb-6">Contact Us</h4>
          <ul className="space-y-4">
            <li className="flex items-center gap-3 text-slate-500">
              <Mail size={18} className="text-primary" /> helloben@gmail.com
            </li>
            <li className="flex items-center gap-3 text-slate-500">
              <Phone size={18} className="text-primary" /> +91 915 430 0354
            </li>
            <li className="flex items-center gap-3 text-slate-500">
              <MapPin size={18} className="text-primary" /> Srikakulam, India
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto pt-10 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-slate-400 text-sm">© 2026 ThynkBEN. All rights reserved.</p>
        <div className="flex gap-8 text-sm text-slate-400">
          <a href="#" className="hover:text-primary">Privacy Policy</a>
          <a href="#" className="hover:text-primary">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [isContactOpen, setIsContactOpen] = useState(false);

  return (
    <div className="min-h-screen selection:bg-primary/20 selection:text-primary">
      <Header onOpenContact={() => setIsContactOpen(true)} />
      <main>
        <Hero onOpenContact={() => setIsContactOpen(true)} />
        <Trust />
        <Services onOpenContact={() => setIsContactOpen(true)} />
        <Solutions />
        <Pricing onOpenContact={() => setIsContactOpen(true)} />
        <Portfolio />
        <Testimonials />
        <FinalCTA onOpenContact={() => setIsContactOpen(true)} />
      </main>
      <Footer />
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
    </div>
  );
}
